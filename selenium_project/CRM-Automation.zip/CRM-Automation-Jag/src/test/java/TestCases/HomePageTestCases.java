package TestCases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.HomePage;

public class HomePageTestCases {

    HomePage home = new HomePage();

    @BeforeTest
    public void beforeTest(){
        home.launchurl();
        home.login();
    }

    @Test
    public void Activity5(){
        String Navbarcolor = home.navigationBarColor();
        System.out.println(Navbarcolor);
    }

    @Test
    public void Activity6() throws InterruptedException {
        home.verifyActivityMenu();
    }

    @Test
    public void Activity7() throws InterruptedException {
        home.navigateToSalesAccount();
        home.getPhoneNumber();
    }

    @Test
    public void Activity8() throws InterruptedException {
        home.getToAccountsTable();
        home.getToAccountsName();
    }

    @Test
    public void Activity9() throws InterruptedException {
        home.navigateToSalesAccount();
        home.getLeadTableNames();
        home.getLeadTableUsers();
    }

    @AfterTest
    public void closingTest(){
        home.quitdriver();
    }
}
