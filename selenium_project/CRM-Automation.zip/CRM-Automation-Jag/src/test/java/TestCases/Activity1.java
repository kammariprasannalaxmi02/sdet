package TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginCMR;

public class Activity1 {
    LoginCMR loginPage = new LoginCMR();

    @Test
    public void Testcase1(){
        loginPage.launchurl();
        String actualText = loginPage.titleVerify();
        System.out.println(actualText);
        String expectedText = "SuiteCRM";
       if(actualText.contentEquals(expectedText)) {
           System.out.println("Title matches the expected");
           loginPage.quitdriver();
       }else{
           System.out.println("Title not matches the expected");
       }
    }
}
