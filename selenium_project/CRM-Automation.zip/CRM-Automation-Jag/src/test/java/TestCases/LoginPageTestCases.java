package TestCases;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.LoginCMR;

public class LoginPageTestCases {
    LoginCMR lcmr = new LoginCMR();

    @BeforeTest
    public void beforeTest(){
        lcmr.launchurl();
    }

    @Test
    public void Activity2(){
    String LinkText = lcmr.getHeaderImageLinkText();
    System.out.println(LinkText);
    }

    @Test
    public void Activity3(){
    String copyright1Message = lcmr.getCopyRightMessage();
    System.out.println(copyright1Message);
    }

    @Test
    public void Activity4()  {
        lcmr.login();
        String expectedText = "MY ACCOUNTS";
        String actualText = lcmr.verifyHomePage();
        Assert.assertEquals(expectedText,actualText);
    }

    @AfterTest
    public void closingDriver(){
        lcmr.quitdriver();
    }

}