package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;



public class HomePage extends LoginCMR {

    By toolbar = By.id("toolbar");
    By salesMenu = By.id("grouptab_0");
    By leadsLink = By.id("moduleTab_9_Leads");
    By ActivityMenu = By.id("grouptab_3");
    By homeButton = By.xpath("//*[@id=\'toolbar\']/ul/li[1]/a");
    By AccountLink = By.id("moduleTab_9_Accounts");

    public String navigationBarColor() {

        String color = driver.findElement(toolbar).getCssValue("color");
        return color;
    }


    public void navigateToSalesAccount() throws InterruptedException {
        Actions actions = new Actions(driver);
        WebElement salesMenuLink = driver.findElement(salesMenu);
        actions.moveToElement(salesMenuLink);
        Thread.sleep(5000);
        WebElement leadLink = driver.findElement(leadsLink);
        actions.moveToElement(leadLink);
        actions.click().build().perform();
        Thread.sleep(10000);
        String actualText = driver.findElement(By.xpath("//*[@id=\'content\']/div[1]/h2")).getText();
        assertNotNull("actual test is not null", actualText);
    }

    public void getPhoneNumber() throws InterruptedException {
        String phoneNumber;
        WebElement descendingLink = driver.findElement(By.xpath("//*[@id=\'MassUpdate\']/div[3]/table/thead/tr[1]/th[9]/div/a/span"));
        descendingLink.click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\'MassUpdate\']/div[3]/table/tbody/tr[1]/td[10]")).click();
        Thread.sleep(10000);
        phoneNumber = driver.findElement(By.xpath("//*[@id=\'ui-id-5\']/span")).getText();
        System.out.println(phoneNumber);
        driver.findElement(By.xpath("//*[@id=\'content\']/div[5]/div[1]/button/span[1]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id=\'MassUpdate\']/div[3]/table/thead/tr[1]/th[9]/div/a/span")).click();
    }

    public void verifyActivitiesLinks() throws InterruptedException {
        //For ArrayList
        String[] arrlist = {"Notes", "Tasks", "Calendar", "Meetings", "Calls", "Emails", "Home"};
        driver.findElement(homeButton).click();
        Thread.sleep(5000);
        for (String item : arrlist) {
            try {
                Actions actions = new Actions(driver);
                WebElement ActivityMenuLink = driver.findElement(ActivityMenu);
                actions.moveToElement(ActivityMenuLink).build().perform();
                Thread.sleep(3000);
                driver.findElement(By.xpath("//ul[@class='dropdown-menu']//li//a[text()='" + item + "']")).click();
                Thread.sleep(5000);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public void verifyActivityMenu() throws InterruptedException {
        driver.findElement(homeButton).click();
        Thread.sleep(3000);
        WebElement activity = driver.findElement(ActivityMenu);
        activity.click();
        Thread.sleep(3000);

    }

    public void getToAccountsTable() throws InterruptedException {
        Actions actions = new Actions(driver);
        WebElement salesMenuLink = driver.findElement(salesMenu);
        actions.moveToElement(salesMenuLink).build().perform();
        Thread.sleep(3000);
        driver.findElement(AccountLink).click();
    }

    public void getToAccountsName() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        List<String> arrlist = new ArrayList<String>();
        String first_part = "//*[@class='list view table-responsive']/tbody/tr[";
        String second_part = "]/td[";
        String third_part = "]/b/a";
        int i = 3;
        for (int j = 1; j <= 10; j += 2) {
            String final_xpath = first_part + j + second_part + i + third_part;
            WebElement name = driver.findElement(By.xpath(final_xpath));
            String listNames = name.getAttribute("innerHTML");
            arrlist.add(listNames);
        }
        System.out.print("Names of the first 5 odd-numbered rows:\n"+arrlist);
    }

 public void getLeadTableNames(){
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     List<String> arrlist = new ArrayList<String>();
     String first_part = "//*[@class='list view table-responsive']/tbody/tr[";
     String second_part = "]/td[";
     String third_part = "]/b/a";
     int i = 3;
     for (int j = 1; j <= 10; j++) {
         String final_xpath = first_part + j + second_part + i + third_part;
         WebElement name = driver.findElement(By.xpath(final_xpath));
         String listNames = name.getAttribute("innerHTML");
         arrlist.add(listNames);
     }
     System.out.print("First 10 values in the Name column:\n"+arrlist);
 }

    public void getLeadTableUsers(){
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        List<String> arrlist = new ArrayList<String>();
        String first_part = "//*[@class='list view table-responsive']/tbody/tr[";
        String second_part = "]/td[";
        String third_part = "]/a";
        int i = 8;
        for (int j = 1; j <= 10; j++) {
            String final_xpath = first_part + j + second_part + i + third_part;
            WebElement name = driver.findElement(By.xpath(final_xpath));
            String listNames = name.getAttribute("innerHTML");
            arrlist.add(listNames);
        }
        System.out.println("\n***************************************************\n");
        System.out.println("\nFirst 10 values in the User column:");
        System.out.print(arrlist);
    }

}