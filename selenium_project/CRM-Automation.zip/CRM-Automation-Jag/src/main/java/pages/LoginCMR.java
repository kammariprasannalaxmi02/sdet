package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import java.util.concurrent.TimeUnit;


public class LoginCMR {

    WebDriver driver = new FirefoxDriver();
    By usernameidentifier = By.id("user_name");
    By passwordidentifier = By.id("username_password");
    By login = By.id("bigbutton");
    By copyright1 = By.id("admin_options");
    By headimage = By.xpath("//*[@id=\'form\']/div[1]/img");
    By textMessage = By.xpath("//*[@id=\'dashlet_header_849b2dac-a202-a5f2-0cf9-5db0c1b02e20\']/div[2]/table/tbody/tr/td[1]/h3/span[2]");
    By userHeader = By.xpath("//*[@id=\'usermenucollapsed\']/span");

    public void launchurl(){
        String url = "https://alchemy.hguy.co/crm";
        driver.get(url);
    }

    public void quitdriver(){
        driver.quit();
    }


    public void login(){
        driver.findElement(usernameidentifier).sendKeys("admin");
        driver.findElement(passwordidentifier).sendKeys("pa$$w0rd");
        driver.findElement(login).click();
    }

    public String titleVerify(){
        return driver.getTitle();
    }

    public String getHeaderImageLinkText(){
        return driver.findElement(headimage).getAttribute("src");
    }

    public String getCopyRightMessage(){
        return driver.findElement(copyright1).getText();
    }


    public String verifyHomePage() {
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS) ;
        String actualtext = driver.findElement(textMessage).getText();
        driver.findElement(userHeader).isDisplayed();
        return actualtext;
    }
}
