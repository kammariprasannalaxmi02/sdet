# SDET_Selenium_CRM_Project

SDET CRM project using Java(TestNG framework).
